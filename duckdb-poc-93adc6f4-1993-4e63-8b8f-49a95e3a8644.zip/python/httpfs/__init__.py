# flake8: noqa
from httpfs.opener import HttpFsOpener
from httpfs._version import __author__, __version__
