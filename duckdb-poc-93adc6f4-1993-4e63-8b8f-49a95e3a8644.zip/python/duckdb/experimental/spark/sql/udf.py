# https://sparkbyexamples.com/pyspark/pyspark-udf-user-defined-function/


class UDFRegistration:
    def __init__(self):
        raise NotImplementedError


__all__ = ["UDFRegistration"]
